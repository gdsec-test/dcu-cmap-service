import logging
from whois import whois
from ipwhois import IPWhois
from celery import Celery, chord
from celery.utils.log import get_task_logger
from celeryconfig import CeleryConfig
import socket
import re
from datetime import datetime
from suds.client import Client
import xml.etree.ElementTree as ET
import json
import validictory

logging.basicConfig()
app = Celery()
app.config_from_object(CeleryConfig())
logger = get_task_logger('celery.tasks')

schema = json.loads(open('schema.json').read())

@app.task
def get_registrar_info(domain):
    w = whois(domain)
    return dict(registrar=w.registrar, registrar_email=w.emails[0])

@app.task
def get_hosting_info(domain):
    domain = 'www.'+ domain if domain[:4] != 'www.' else domain[4:]
    ip = socket.gethostbyname(domain)
    regex = re.compile('[^a-zA-Z]')
    info = IPWhois(ip).lookup_rdap()
    name = regex.sub('', info.get('network',[]).get('name', ''))
    email = info.get('objects').get('ABUSE51-ARIN').get('contact').get('email')[0].get('value')
    return dict(host_network=name, host_network_email=email)

@app.task
def finish(domain_info):
    logger.info("Finished processing {}".format(domain_info))
    data = dict()
    if isinstance(domain_info, list):
        for item in domain_info:
            data.update(item)
    else:
        data=domain_info
    return data

@app.task
def get_shopper_info(domain):
    """
    Returns a tuple containing the shopper id, and the date created
    :param domain:
    :return:
    """
    ret = dict(shopper='', created='')
    try:
        doc = ET.fromstring(_lookup_shopper_info(domain))
        elem = doc.find(".//*[@shopper_id]")
        ret['shopper']=elem.get('shopper_id')
        ret['created']=datetime.strptime(elem.get('date_created'), '%m/%d/%Y %I:%M:%S %p')
    except Exception as e:
        logger.error("Unable to lookup shopper info for {}:{}".format(domain, e))
    finally:
        return ret

def _lookup_shopper_info(domain):
    """
    Returns the xml representing the shopper id(s)
    :param domain:
    :return:
    """
    shopper_search = ET.Element("ShopperSearch", IPAddress='', RequestedBy='DCU-ENG')
    searchFields = ET.SubElement(shopper_search, 'SearchFields')
    ET.SubElement(searchFields, 'Field', Name='domain').text = domain

    returnFields = ET.SubElement(shopper_search, "ReturnFields")
    ET.SubElement(returnFields, 'Field', Name='shopper_id')
    ET.SubElement(returnFields, 'Field', Name='date_created')
    xmlstr = ET.tostring(shopper_search, encoding='utf8', method='xml')
    # The following Fort Knox client will timeout on the dev side, unless a firewall rule is created
    #  allowing access from dev Rancher, which means no shopper id, account create date, etc when
    #  running from dev
    client = Client('https://shopper.prod.phx3.gdg/WSCgdShopper/WSCgdShopper.dll?Handler=GenWSCgdShopperWSDL', timeout=5)
    return client.service.SearchShoppers(xmlstr)

@app.task
def get_domain_info(data):
    try:
        validictory.validate(json.loads(json.dumps(data)), schema)
    except ValueError as error:
        return {'error':error}

    callback = finish.s()
    domain = data['payload']['domain']
    header = []
    for item in data.get('fields'):
        data = item['data']
        if data =='hosting':
           header.append(get_hosting_info.s(domain))
        if data =='registrar':
            header.append(get_registrar_info.s(domain))
        if data =='shopper':
            header.append(get_shopper_info.s(domain))
    return chord(header)(callback)


